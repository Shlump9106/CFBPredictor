| Rank  | Team                 | Conference           | Record   | Rating | Deviation |
| ---:  | ---:                 | ---:                 | ---:     | ---:   | ---:      |
| 1     | Oregon               | Big Ten              | 13-1     | 3044   | 89        |
| 2     | Ohio State           | Big Ten              | 14-2     | 2986   | 81        |
| 3     | Notre Dame           | FBS Independents     | 14-2     | 2789   | 81        |
| 4     | Penn State           | Big Ten              | 13-3     | 2721   | 80        |
| 5     | Indiana              | Big Ten              | 11-2     | 2624   | 85        |
| 6     | Texas                | SEC                  | 13-3     | 2566   | 75        |
| 7     | Georgia              | SEC                  | 11-3     | 2553   | 72        |
| 8     | Boise State          | Mountain West        | 12-2     | 2517   | 96        |
| 9     | Illinois             | Big Ten              | 10-3     | 2496   | 77        |
| 10    | Michigan             | Big Ten              | 8-5      | 2454   | 73        |
| 11    | Tennessee            | SEC                  | 10-3     | 2382   | 76        |
| 12    | BYU                  | Big 12               | 11-2     | 2345   | 73        |
| 13    | South Carolina       | SEC                  | 9-4      | 2338   | 66        |
| 14    | SMU                  | ACC                  | 11-3     | 2330   | 73        |
| 15    | Ole Miss             | SEC                  | 10-3     | 2329   | 71        |
| 16    | Alabama              | SEC                  | 9-4      | 2326   | 68        |
| 17    | Arizona State        | Big 12               | 11-3     | 2316   | 72        |
| 18    | LSU                  | SEC                  | 9-4      | 2315   | 64        |
| 19    | Missouri             | SEC                  | 10-3     | 2287   | 68        |
| 20    | Iowa State           | Big 12               | 11-3     | 2274   | 68        |
| 21    | Clemson              | ACC                  | 10-4     | 2271   | 72        |
| 22    | Florida              | SEC                  | 8-5      | 2267   | 69        |
| 23    | Louisville           | ACC                  | 9-4      | 2239   | 68        |
| 24    | Minnesota            | Big Ten              | 8-5      | 2232   | 68        |
| 25    | USC                  | Big Ten              | 7-6      | 2231   | 66        |

Updated 05/03/2025 23:15:17
