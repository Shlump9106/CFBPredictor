| Rank  | Team                 | Conference           | Record   | Rating |
| ---:  | ---:                 | ---:                 | ---:     | ---:   |
| 1     | Georgia              | SEC                  | 7-0      | 3751   |
| 2     | Oklahoma             | Big 12               | 6-0      | 3371   |
| 3     | Ohio State           | Big Ten              | 6-0      | 3232   |
| 4     | Louisville           | ACC                  | 6-0      | 3158   |
| 5     | Penn State           | Big Ten              | 5-0      | 3033   |
| 6     | Texas                | Big 12               | 5-1      | 3002   |
| 7     | Florida State        | ACC                  | 6-0      | 2994   |
| 8     | Michigan             | Big Ten              | 7-0      | 2976   |
| 9     | Kentucky             | SEC                  | 5-1      | 2776   |
| 10    | Alabama              | SEC                  | 6-1      | 2744   |
| 11    | North Carolina       | ACC                  | 5-0      | 2720   |
| 12    | James Madison        | Sun Belt             | 6-0      | 2708   |
| 13    | Notre Dame           | FBS Independents     | 5-2      | 2700   |
| 14    | Washington           | Pac-12               | 5-0      | 2672   |
| 15    | USC                  | Pac-12               | 6-0      | 2639   |
| 16    | Oregon               | Pac-12               | 5-0      | 2615   |
| 17    | Washington State     | Pac-12               | 4-1      | 2582   |
| 18    | Ole Miss             | SEC                  | 5-1      | 2578   |
| 19    | Utah                 | Pac-12               | 5-1      | 2561   |
| 20    | Oregon State         | Pac-12               | 5-1      | 2557   |
| 21    | UCLA                 | Pac-12               | 4-1      | 2554   |
| 22    | Wyoming              | Mountain West        | 5-1      | 2509   |
| 23    | Iowa                 | Big Ten              | 5-1      | 2460   |
| 24    | Air Force            | Mountain West        | 5-0      | 2457   |
| 25    | Liberty              | Conference USA       | 6-0      | 2423   |

Updated 10/14/2023 18:13:28
